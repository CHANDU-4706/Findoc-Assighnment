import 'package:flutter/material.dart';
import 'features/login/view/login_screen.dart';
import 'features/photos/view/home_screen.dart';

class AppRouter {
  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    switch (settings.name) {
      case HomeScreen.routeName:
        return MaterialPageRoute(builder: (_) => const HomeScreen());
      case LoginScreen.routeName:
      default:
        return MaterialPageRoute(builder: (_) => const LoginScreen());
    }
  }
}
