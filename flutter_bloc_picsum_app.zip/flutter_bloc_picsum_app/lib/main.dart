import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

import 'app_router.dart';
import 'features/login/cubit/login_cubit.dart';
import 'features/photos/bloc/photos_bloc.dart';
import 'features/photos/data/photos_repository.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final photosRepository = PhotosRepository();

    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (_) => LoginCubit()),
        BlocProvider(create: (_) => PhotosBloc(repository: photosRepository)..add(const PhotosRequested(limit: 10))),
      ],
      child: MaterialApp(
        title: 'Flutter BLoC Picsum',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorSchemeSeed: Colors.indigo,
          useMaterial3: true,
          textTheme: GoogleFonts.montserratTextTheme(),
        ),
        onGenerateRoute: AppRouter.onGenerateRoute,
      ),
    );
  }
}
