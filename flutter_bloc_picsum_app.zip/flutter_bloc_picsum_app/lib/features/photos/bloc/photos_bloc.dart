import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../data/models/photo.dart';
import '../data/photos_repository.dart';

part 'photos_event.dart';
part 'photos_state.dart';

class PhotosBloc extends Bloc<PhotosEvent, PhotosState> {
  final PhotosRepository repository;

  PhotosBloc({required this.repository}) : super(const PhotosState.loading()) {
    on<PhotosRequested>(_onRequested);
  }

  Future<void> _onRequested(PhotosRequested event, Emitter<PhotosState> emit) async {
    emit(const PhotosState.loading());
    try {
      final photos = await repository.fetchPhotos(limit: event.limit);
      emit(PhotosState.loaded(photos));
    } catch (e) {
      emit(PhotosState.error(e.toString()));
    }
  }
}
