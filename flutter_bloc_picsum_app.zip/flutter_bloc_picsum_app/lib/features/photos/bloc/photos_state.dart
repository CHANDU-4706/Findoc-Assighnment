part of 'photos_bloc.dart';

class PhotosState extends Equatable {
  final List<Photo> photos;
  final bool isLoading;
  final String? error;

  const PhotosState({
    required this.photos,
    required this.isLoading,
    this.error,
  });

  const PhotosState.loading() : this(photos: const [], isLoading: true);
  const PhotosState.loaded(List<Photo> photos) : this(photos: photos, isLoading: false);
  const PhotosState.error(String message) : this(photos: const [], isLoading: false, error: message);

  @override
  List<Object?> get props => [photos, isLoading, error];
}
