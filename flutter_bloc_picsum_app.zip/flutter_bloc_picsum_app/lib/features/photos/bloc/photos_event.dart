part of 'photos_bloc.dart';

abstract class PhotosEvent extends Equatable {
  const PhotosEvent();
  @override
  List<Object?> get props => [];
}

class PhotosRequested extends PhotosEvent {
  final int limit;
  const PhotosRequested({this.limit = 10});

  @override
  List<Object?> get props => [limit];
}
