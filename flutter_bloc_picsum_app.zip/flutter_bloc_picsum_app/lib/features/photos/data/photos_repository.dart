import 'package:http/http.dart' as http;
import 'models/photo.dart';

class PhotosRepository {
  final http.Client _client;
  PhotosRepository({http.Client? client}) : _client = client ?? http.Client();

  Future<List<Photo>> fetchPhotos({int limit = 10}) async {
    final uri = Uri.parse('https://picsum.photos/v2/list?limit=$limit');
    final res = await _client.get(uri);
    if (res.statusCode == 200) {
      return Photo.listFromJson(res.body);
    } else {
      throw Exception('Failed to fetch photos: ${res.statusCode}');
    }
  }
}
