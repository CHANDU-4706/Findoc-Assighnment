import 'dart:convert';

class Photo {
  final String id;
  final String author;
  final int width;
  final int height;
  final String url;
  final String downloadUrl;

  Photo({
    required this.id,
    required this.author,
    required this.width,
    required this.height,
    required this.url,
    required this.downloadUrl,
  });

  double get aspectRatio => width == 0 ? 1.0 : height / width;

  factory Photo.fromMap(Map<String, dynamic> map) {
    return Photo(
      id: map['id'].toString(),
      author: map['author'] ?? 'Unknown',
      width: (map['width'] ?? 0) is int ? (map['width'] ?? 0) : int.tryParse(map['width'].toString()) ?? 0,
      height: (map['height'] ?? 0) is int ? (map['height'] ?? 0) : int.tryParse(map['height'].toString()) ?? 0,
      url: map['url'] ?? '',
      downloadUrl: map['download_url'] ?? '',
    );
  }

  static List<Photo> listFromJson(String source) {
    final data = json.decode(source);
    if (data is List) {
      return data.map((e) => Photo.fromMap(e)).toList();
    }
    return [];
  }
}
