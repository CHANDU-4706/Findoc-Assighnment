import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

part 'login_state.dart';

class LoginCubit extends Cubit<LoginState> {
  LoginCubit() : super(const LoginState());

  void emailChanged(String value) {
    emit(state.copyWith(email: value));
  }

  void passwordChanged(String value) {
    emit(state.copyWith(password: value));
  }

  Future<void> submit() async {
    // Simulate a short delay to mimic async work (e.g., API) if needed.
    emit(state.copyWith(status: LoginStatus.submitting));
    await Future.delayed(const Duration(milliseconds: 400));
    emit(state.copyWith(status: LoginStatus.success));
  }
}
